<?php $__env->startSection('content'); ?>

    <!-- Page Header Start -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Order Detail</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="<?php echo e(route('home')); ?>">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Order detail</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->

    <!-- Checkout Start -->
    <div class="container-fluid pt-5">
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('checkoutPost')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row px-xl-5">
                <div class="col-lg-7 pl-5">
                    <div class="mb-4">
                        <h4 class="font-weight-semi-bold mb-4">Billing Address</h4>
                        <div class="row">
                            <div class="col-md-12 form-group">
                                <label>Name</label>
                                <input class="form-control" value="<?php echo e($order->name); ?>" disabled readonly>
                            </div>
                            <div class="col-md-12 form-group">
                                <label>E-mail</label>
                                <input class="form-control" value="<?php echo e($order->email); ?>" disabled readonly>
                            </div>
                            <div class="col-md-12 form-group">
                                <label>Phone</label>
                                <input class="form-control" type="number" value="<?php echo e($order->phone); ?>" disabled readonly>
                            </div>
                            <div class="col-md-12 form-group">
                                <label>Address</label>
                                <input class="form-control" type="text" value="<?php echo e($order->address); ?>" disabled readonly>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 pr-5">
                    <div class="card border-secondary mb-5">
                        <div class="card-header bg-secondary border-0">
                            <h4 class="font-weight-semi-bold m-0">Order Total</h4>
                        </div>
                        <div class="card-body">
                            <h5 class="font-weight-medium mb-3">Products</h5>
                                <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex justify-content-between">
                                        <span><?php echo e($product->pivot->name); ?> - <?php echo e($product->pivot->color); ?> x <?php echo e($product->pivot->quantity); ?>

                                            <p style="font-size: 13px">Size: <?php echo e($product->pivot->size); ?></p>
                                        </span>
                                        <p><?php echo e(number_format($product->pivot->price * $product->pivot->quantity)); ?>đ</p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <hr class="mt-0">
                            <div class="d-flex justify-content-between mb-3 pt-1">
                                <h6 class="font-weight-medium">Subtotal</h6>
                                <h6 class="font-weight-medium"><?php echo e(number_format($order->total_price)); ?>đ</h6>
                            </div>
                            <div class="d-flex justify-content-between">
                                <h6 class="font-weight-medium">Shipping</h6>
                                <h6 class="font-weight-medium">Free</h6>
                            </div>
                        </div>
                        <div class="card-footer border-secondary bg-transparent">
                            <div class="d-flex justify-content-between mt-2">
                                <h5 class="font-weight-bold">Total</h5>
                                <h5 class="font-weight-bold"><?php echo e(number_format($order->total_price)); ?>đ</h5>
                            </div>
                        </div>
                    </div>
                    <div class="card border-secondary mb-5">
                        <div class="card-header bg-secondary border-0">
                            <h4 class="font-weight-semi-bold m-0">Payment</h4>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label><?php echo e($order->payment == 1 ? 'VNPay' : 'Cash on delivery (COD)'); ?></label>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </form>
        
    </div>
    <!-- Checkout End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shoe_store\resources\views/frontend/order-detail.blade.php ENDPATH**/ ?>