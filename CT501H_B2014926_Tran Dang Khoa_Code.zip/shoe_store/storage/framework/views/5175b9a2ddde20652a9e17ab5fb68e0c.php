

<?php $__env->startSection('content'); ?>

<!-- Page Header Start -->
<div class="container-fluid bg-secondary mb-5">
    <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
        <h1 class="font-weight-semi-bold text-uppercase mb-3">Blog</h1>
        <div class="d-inline-flex">
            <p class="m-0"><a href="<?php echo e(route('home')); ?>">Home</a></p>
            <p class="m-0 px-2">-</p>
            <p class="m-0">Blog</p>
        </div>
    </div>
</div>
<!-- Page Header End -->

<section class="blog-section spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 order-1 order-lg-2">
                <div class="row">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-sm-4">
                            <div class="blog-item">
                                <div class="bi-pic">
                                    <img src="<?php echo e($post->thumbnail); ?>" alt="thumbnail">
                                </div>
                                <div class="bi-text">
                                    <a href="<?php echo e(route('blog.detail', $post)); ?>">
                                        <h4><?php echo e($post->title); ?></h4>
                                    </a>
                                    <p><?php echo e($post->postType->name); ?> <span>- <?php echo e(date_format($post->created_at, "M d, Y")); ?></span></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="d-flex justify-content-center">
                    <?php echo e($posts->links()); ?>

                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shoe_store\resources\views/frontend/blog.blade.php ENDPATH**/ ?>